import pandas as pd
import re
import string
import numpy as np
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk
import pickle
import numpy as np
import streamlit as st
from keras.preprocessing.text import Tokenizer
from keras_preprocessing.sequence import pad_sequences
import time
import streamlit as st
from PIL import Image
from IPython.display import Audio
import base64
import streamlit as st


def autoplay_audio(file_path: str):
    with open(file_path, "rb") as f:
        data = f.read()
        b64 = base64.b64encode(data).decode()
        md = f"""
            <audio controls autoplay="true">
            <source src="data:audio/mp3;base64,{b64}" type="audio/mp3">
            </audio>
            """
        st.markdown(
            md,
            unsafe_allow_html=True,
        )


classifier=pickle.load(open("spam.pkl","rb"))
tokenizer=pickle.load(open("token.pkl","rb"))


def remove_hyperlink(word):
    return  re.sub(r"http\S+", "", word)

def to_lower(word):
    result = word.lower()
    return result

def remove_number(word):
    result = re.sub(r'\d+', '', word)
    return result

def remove_punctuation(word):
    result = word.translate(str.maketrans(dict.fromkeys(string.punctuation)))
    return result

def replace_newline(word):
    return word.replace('\n','')

def stop_words_removal(word):
    return word.replace('\n','')

def remove_stopwords(sentence):
    stop_words = set(stopwords.words("english"))
    words = sentence.split()
    words = [word for word in words if word not in stop_words]
    return " ".join(words)

def lemmatize_text(sentence):
    lemmatizer = WordNetLemmatizer()
    words = sentence.split()
    words = [lemmatizer.lemmatize(word) for word in words]
    return " ".join(words)

def remove_special_characters(word):
    result = re.sub(r'[^\w\s]', '', word)
    return result

def clean_up_pipeline(sentence):
    cleaning_utils = [remove_hyperlink,
                      replace_newline,
                      to_lower,
                      remove_number,
                      remove_punctuation,remove_special_characters]
    for o in cleaning_utils:
        sentence = o(sentence)
    return sentence
def main():
    st.title(":grey[Spam detection]")
    msg=st.text_input("Enter text here")

    page_bg_img=""" <style>[data-testid="block-container"]{
    background-color: #e6f7e6;
    opacity: 0.8;
    background-image: url("https://media.istockphoto.com/photos/spam-picture-id475067350");
    #radial-gradient(  circle at center center, #444cf7, #e6f7e6), repeating-radial-gradient(circle at center center, #444cf7, #444cf7, 10px, transparent 20px, transparent 10px);
    #background-blend-mode: multiply; 
    background-size: cover;
    }</style>
    """
    st.markdown(page_bg_img,unsafe_allow_html=True)
    if st.button("predict"):
        msg = clean_up_pipeline(msg)
        msg_list = [msg]  # Convert the message to a list
        # Tokenize the input message using the same tokenizer used during training
        sequences = tokenizer.texts_to_sequences(msg_list)
        # Pad the sequence to the same length as the training data
        msg_padded = pad_sequences(sequences, maxlen=3422, padding="post", truncating="post")
        # Predict using the model
        prediction = classifier.predict([msg_padded, msg_padded])
        # The 'prediction' variable contains the probability of the message belonging to the positive class (category 1)
        # You can interpret the prediction based on your threshold (e.g., 0.5) to classify it as spam or not spam.

        # For example:
        threshold = 0.5
        if prediction[0, 0] > threshold:
            st.error("spam")
            img = Image.open("spamemail.PNG")
            st.image(img, width=200)
            autoplay_audio("/content/spam.wav")
        else:
            st.write("not a spam")
            autoplay_audio("/content/nospam.wav")


main()
